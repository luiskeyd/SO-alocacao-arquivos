/*=============================================================
Arquivo de especificação da estrutura do disco e suas funções
Autores: Willy Kauã, Luis Eduardo, Edmar Miqueias, Glezier Montalvane.
Data: Dezembro de 2025
===============================================================*/

#ifndef DISCO_H
#define DISCO_H
#include "arquivo.h"

#define TAM_DISCO 50  // Tamanho total do disco em blocos

typedef struct {
  Arquivo *arquivo; // Ponteiro para o arquivo alocado no bloco
  int ocupado; // 0 para livre, 1 para ocupado
  int proximo; // Utilizado somente na alocação encadeada
} Bloco;

extern Bloco disco[TAM_DISCO];

void inicializarDisco(); // Inicializa o disco, marcando todos os blocos como livres
void mostrarDisco(); // Mostra o estado atual do disco
Arquivo *buscarArquivo(Bloco disco[], char nome);
int isEmpty(Bloco disco[]);

#endif